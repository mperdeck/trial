require('ts-node/register');

var main = require('./main.ts');

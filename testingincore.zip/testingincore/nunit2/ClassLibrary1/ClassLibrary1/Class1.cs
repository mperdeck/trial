﻿using System;

namespace ClassLibrary1
{
    public class Class1
    {
        public static int F1()
        {
            return 5;
        }

    }
}

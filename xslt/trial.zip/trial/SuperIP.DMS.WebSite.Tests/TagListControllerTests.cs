﻿using System;
using System.Collections.Generic;
using System.Net.Http;
using System.Web.Http;
using NUnit.Framework;
using NSubstitute;
using SuperIP.Core.Web.ApiControllers;
using SuperIP.Core.Web.ApiPipeline;
using SuperIP.DMS.Services.Interface;
using SuperIP.DMS.Services.Validation;
using SuperIP.DMS.WebSite.Controllers;
using SuperIP.DMS.WebSite.ViewModels;
using System.IO;
using Newtonsoft.Json;
using SuperIP.Core.Model.Api;
using  SuperIP.Core.Web.Tests;

namespace SuperIP.DMS.WebSite.Tests
{
	[TestFixture]
	public class TagListControllerTests
	{

		public class GetTagMethod : TagListControllerTests
		{
			[Test]
			public void NoIdGiven_ReturnError()
			{
				// Arrange

				var tagDataService = Substitute.For<ITagDataService>();
				var validationMessageService = new ValidationMessageService();

				var tagListController = WebsiteTestHelpers.MockController<TagListController>(validationMessageService);
				tagListController.TagDataService = tagDataService;

				string noId = "";

				// Act

				HttpResponseMessage httpResponseMessage = tagListController.GetTag(null, noId);

				// Assert

				IList<string> errorCodes = httpResponseMessage.GetErrorCodes<TagViewModel>();

				Assert.That(errorCodes.Count, Is.EqualTo(1));
				Assert.That(errorCodes[0], Is.EqualTo("TAG_RETRIEVE_FAIL"));
			}
		}
	}
}

﻿using System;
using System.Collections.Generic;
using NUnit.Framework;
using NSubstitute;
using SuperIP.Core.Model.Web;
using SuperIP.DMS.Model.Common;

namespace SuperIP.DMS.Model.Tests
{
	[TestFixture]
	public class PagedListTests
	{
		public class AddUnpagedListKendoMethod : PagedListTests
		{
			[Test]
			public void NoFilterNoSortOnePage_FullFirstPage()
			{
				// Arrange

				var values = new List<int> {1, 2, 3};

				// Act 

				var page1 = new PagedList<int>();
				page1.AddUnpagedListKendo(values, new KendoQueryContainer() {Page = 1, PageSize = 3}, true);

				// Assert

				CollectionAssert.AreEqual(values, page1);
			}
		}
	}
}
